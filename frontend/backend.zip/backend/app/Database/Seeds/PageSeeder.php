<?php namespace App\Database\Seeds;

class PageSeeder extends \CodeIgniter\Database\Seeder{
  public function run()
  {
    $sobre = [
      'name' => 'sobremi',
      'content' => '{"title":"","subtitle":"","content":""}'
    ];
  
    $social = [
      'name' => 'social',
      'content' => '{"facebook":"","whatsapp":"","youtube":"","link_plano":"","instagram":""}' 
    ];

    $this->db->table('pages')->insert($sobre);
    $this->db->table('pages')->insert($social);
  }
}