<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddPageSchema extends Migration {
	public function up() {
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'name' => array(
				'type' => 'VARCHAR',
				'constraint' => 60,
				'null' => FALSE
			),
			'content' => array(
				'type' => 'TEXT',
				'null' => FALSE
			),
			'updated_at' => array(
				'type' => 'DATETIME',
			),
			'created_at' => array(
				'type' => 'DATETIME',
			),
			'deleted_at' => array(
				'type' => 'DATETIME',
			)
		);
		$this->forge->addField($fields);
		$this->forge->addKey('id', TRUE);
		$this->forge->createTable('pages', TRUE);
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropTable('pages', TRUE);
	}
}
