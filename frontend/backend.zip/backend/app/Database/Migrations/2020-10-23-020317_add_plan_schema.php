<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddPlanSchema extends Migration {
	public function up() {
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => 50,
				'null' => FALSE
			),
			'description' => array(
				'type' => 'VARCHAR',
				'constraint' => 200,
				'null' => FALSE
			),
			'img_url' => array(
				'type' => 'VARCHAR',
				'constraint' => 350,
				'null' => FALSE
			),
			'updated_at' => array(
				'type' => 'DATETIME',
			),
			'created_at' => array(
				'type' => 'DATETIME',
			),
			'deleted_at' => array(
				'type' => 'DATETIME',
			)
		);
		$this->forge->addField($fields);
		$this->forge->addKey('id', TRUE);
		$this->forge->createTable('plans', TRUE);
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropTable('plans', TRUE);
	}
}
