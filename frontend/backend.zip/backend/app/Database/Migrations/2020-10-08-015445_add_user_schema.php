<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddUserSchema extends Migration {
	public function up() {
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'name' => array(
				'type' => 'VARCHAR',
				'constraint' => 64,
				'null' => FALSE
			),
			'email' => array(
				'type' => 'VARCHAR',
				'constraint' => 84,
				'unique' => TRUE
			),
			'password_hash' => array(
				'type' => 'VARCHAR',
				'constraint' => 64
			),
			'role' => array(
				'type' => 'ENUM("admin")',
				'null' => FALSE,
				'default' => "admin"
			),
			'updated_at' => array(
				'type' => 'DATETIME',
			),
			'created_at' => array(
				'type' => 'DATETIME',
			),
			'deleted_at' => array(
				'type' => 'DATETIME',
			)
		);
		$this->forge->addField($fields);
		$this->forge->addKey('id', TRUE);
		$this->forge->createTable('users', TRUE);
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropTable('users');
	}
}
