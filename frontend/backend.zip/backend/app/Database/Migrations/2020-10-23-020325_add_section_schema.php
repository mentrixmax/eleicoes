<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddSectionSchema extends Migration {
	public function up() {
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'plan_id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE
			),
			'label' => array(
				'type' => 'VARCHAR',
				'constraint' => 50,
				'null' => FALSE
			),
			'content' => array(
				'type' => 'TEXT',
				'null' => FALSE
			),
			'updated_at' => array(
				'type' => 'DATETIME',
			),
			'created_at' => array(
				'type' => 'DATETIME',
			),
			'deleted_at' => array(
				'type' => 'DATETIME',
			)
		);
		$this->forge->addField($fields);
		$this->forge->addKey('id', TRUE);
		$this->forge->createTable('sections', TRUE);
		$this->forge->addColumn('sections', 'CONSTRAINT `section-plan` FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE CASCADE');
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropTable('sections', TRUE);
	}
}
