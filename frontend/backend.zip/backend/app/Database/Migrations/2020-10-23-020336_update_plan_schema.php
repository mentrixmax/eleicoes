<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdatePlanSchema extends Migration {
	public function up() {
		$this->forge->addColumn('plans','color INT(2) UNSIGNED DEFAULT 0');
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropColumn('plans','color');
	}
}
