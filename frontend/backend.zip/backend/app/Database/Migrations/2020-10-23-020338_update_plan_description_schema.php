<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdatePlanDescriptionSchema extends Migration {
	public function up() {
		$this->db->query("ALTER TABLE `plans` CHANGE `description` `description` VARCHAR(300) NULL");
	}

	//--------------------------------------------------------------------

	public function down() {
		
	}
}
