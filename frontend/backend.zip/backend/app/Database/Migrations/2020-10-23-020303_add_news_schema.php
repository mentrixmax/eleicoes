<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddNewsSchema extends Migration {
	public function up() {
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 10,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => 100,
				'null' => FALSE
			),
			'link' => array(
				'type' => 'VARCHAR',
				'constraint' => 255,
				'null' => FALSE
			),
			'img_url' => array(
				'type' => 'VARCHAR',
				'constraint' => 350,
				'null' => FALSE
			),
			'is_video' => array(
				'type' => 'BOOLEAN',
				'null' => FALSE,
				'default' => FALSE
			),
			'updated_at' => array(
				'type' => 'DATETIME',
			),
			'created_at' => array(
				'type' => 'DATETIME',
			),
			'deleted_at' => array(
				'type' => 'DATETIME',
			)
		);
		$this->forge->addField($fields);
		$this->forge->addKey('id', TRUE);
		$this->forge->createTable('news', TRUE);
	}

	//--------------------------------------------------------------------

	public function down() {
		$this->forge->dropTable('news', TRUE);
	}
}
