<?php 
	include ('paginas/index.html');
?>