<?php


namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use Config\Services;
use Firebase\JWT\JWT;


class User extends ResourceController {

	public function __construct() {
		$this->userModel = model('App\Models\User');
	}

	public function create() {
		if (count($this->userModel->find()) == 0) {
			$user = $this->request->getJSON();
			$registered = $this->userModel->insert($user);
			if (!$registered) {
				return $this->respond($this->userModel->errors(), 400);
			}
			return $this->respondCreated($registered);
		} else {
			return $this->respond(null, 404);
		}
	}

	public function auth() {
		try {
			$input 		= $this->request->getJSON();

			$email 		= isset($input->email)		? 	$input->email 		: null;
			$password	= isset($input->password)	? 	$input->password 	: null;

			$user = $this->userModel->checkLogin($email);

			if ($user) {
				if (password_verify($password, $user->password_hash)) {
					$secret_key 		= Services::getSecret();
					$issued_at			= time();
					$expire_claim		= time() + 36000;

					$token = [
						'iat'	=> $issued_at,
						'exp' => $expire_claim,
						'data' => [
							'id' => $user->id
						]
					];

					$responseUser = [
						'id'		=> $user->id,
						'name' 	=> $user->name,
						'email'	=> $user->email
					];

					$jwt = JWT::encode($token, $secret_key);

					return $this->respond([
						'message' 	=> 'Login efetuado com sucesso!',
						'type'			=> 'Bearer',
						'token' 		=> $jwt,
						'expiresAt' => (time() + 36000) * 1000,
						'user'			=> $responseUser
					], 200);
				}
			}
			return $this->respond(null, 401);
		} catch (\Exception $e) {
		}
		return $this->response->setStatusCode(400);
	}

	public function options() {
		return $this->response
			->setHeader('Access-Control-Allow-Origin', '*') //for allow any domain, insecure
			->setHeader('Access-Control-Allow-Headers', '*') //for allow any headers, insecure
			->setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
	}
}
