<?php


namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;


class Plan extends ResourceController {

	public function __construct() {
		$this->model = model('App\Models\Plan');
	}

	public function index() {
		$registered = $this->model->findAll();
		return $this->respond($registered);
	}

	public function show($id = null) {
		$item = $this->model->find($id);
		if ($item) {
			$sectionModel = model('App\Models\Section');
			$item->sections = $sectionModel->where('plan_id', $id)->findAll();
		}
		return $this->respond($item);
	}

	public function create() {
		$input = $this->request->getJSON();
		$sections = $input->sections;
		unset($input->sections);

		$registered = $this->model->insert($input);
		if (!$registered) {
			return $this->respond($this->model->errors(), 400);
		} else {
			$sectionModel = model('App\Models\Section');
			$sections = array_map(function ($el) use ($registered) {
				$el->plan_id = $registered;
				return $el;
			}, $sections);
			if ($sections) {
				$batch = $sectionModel->insertBatch($sections);
				if (!$batch) {
					return $this->respond($sectionModel->errors(), 200);
				}
			}
		}
		return $this->respondCreated();
	}

	public function update($id = NULL) {
		$input = $this->request->getJSON();
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->update($id, $input);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondUpdated();
		}
	}

	public function delete($id = NULL) {
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->delete($id);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondDeleted();
		} else {
			return $this->respond($this->model->errors(), 400);
		}
	}
}
