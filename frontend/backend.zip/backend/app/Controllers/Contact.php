<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use Exception;

class Contact extends ResourceController {

	public function send() {
		try {
			$email = \Config\Services::email();

			$from = "contato@wiltonfraga.com.br";
			$to = "wiltonfragacandidato@gmail.com";
			$input = $this->request->getJSON();

			$email->setNewline("\r\n");
			$email->setFrom($from, 'Contato Wilton Fraga');
			$email->setTo($to);

			$email->setSubject('Olá, Tenho uma proposta para ti');
			$email->setMessage("Olá! Professor Wilton, gostaria de contribuir com o plano de trabalho com a proposta abaixo:\n\n$input->proposta\n\nPara entrar em contato usar: $input->contato");
			if ($email->send()) {
				return $this->respondCreated();
			} else {
				$data = $email->printDebugger(['headers']);
				print_r($data);
				return $this->respond('Error', 400);
			}

			return $this->respondCreated();
		} catch (\Exception $e) {
			return $this->respond(null, 400);
		}
	}
}
