<?php


namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;


class Page extends ResourceController {

	public function __construct() {
		$this->model = model('App\Models\Page');
	}

	public function index() {
		$registered = $this->model->findAll();
		return $this->respond($registered);
	}

	public function images() {
		$files = glob('assets/img/uploads/*');
		array_multisort(
				array_map( 'filemtime', $files ),
				SORT_NUMERIC,
				SORT_DESC,
				$files
		);
		//$files = array_diff(scandir('./assets/img/uploads'), array('.', '..','.gitkeep'));
		return $this->respond($files);
	}
	
	public function images_upload() {
		$file = $this->request->getFile('file');
		if($file){
			if ($file->isValid() && ! $file->hasMoved()){
				$ok = $this->validate([
					'file' => 'is_image[file]|max_size[file,2048]'
				]);
				if($ok){
					$newName = $file->getRandomName();
					$file->move('./assets/img/uploads', $newName);
				}else{
					return $this->respond($this->error,400);
				}
      }
		}
		return $this->respondCreated();
	}

	public function show($id = null) {
		$item = $this->model->find($id);
		if ($item) {
			return $this->respond($item);
		}
		return $this->respond(null, 400);
	}

	public function create() {
		$input = $this->request->getJSON();
		$registered = $this->model->insert($input);
		if (!$registered) {
			return $this->respond($this->model->errors(), 400);
		}
		return $this->respondCreated();
	}

	public function update($id = NULL) {
		$input = $this->request->getJSON();
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->update($id, $input);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondUpdated();
		}
	}

	public function delete($id = NULL) {
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->delete($id);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondDeleted();
		} else {
			return $this->respond($this->model->errors(), 400);
		}
	}

	public function getByName($name)
	{
		$item = $this->model->where('name',$name)->first();
		if ($item) {
			return $this->respond($item);
		}
		return $this->respond(null, 400);
	}
}
