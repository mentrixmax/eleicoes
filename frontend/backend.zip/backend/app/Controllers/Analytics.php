<?php


namespace App\Controllers;

use Google_Client;
use CodeIgniter\RESTful\ResourceController;
use DateTime;
use Google_Service_Analytics;

/**
 * Initializes an Analytics Reporting API V4 service object.
 *
 * @return An authorized Analytics Reporting API V4 service object.
 */
function initializeAnalytics() {
  $KEY_FILE_LOCATION = ROOTPATH . '/service-account-credentials.json';

  $client = new Google_Client();
  $client->setApplicationName("Site Wilton Fraga");
  $client->setAuthConfig($KEY_FILE_LOCATION);
  $client->setScopes(['https://www.googleapis.com/auth/analytics.readonly']);
  $analytics = new Google_Service_Analytics($client);

  return $analytics;
}


function getLastYear($analytics) {
  $qry = $analytics->data_ga->get(
    'ga:232325563',
    '120daysAgo',
    'today',
    'ga:sessions',
    [
      'dimensions' => 'ga:isoYear'
    ]
  );

  $data = $qry->getRows();
  if ($data && count($data) > 0) {
    $lastYear = $data[count($data) - 1];
    return $lastYear;
  }

  return [date_format(new DateTime(), "Y") => 0];
}

function getLastWeek($analytics) {
  $qry = $analytics->data_ga->get(
    'ga:232325563',
    '7daysAgo',
    'today',
    'ga:sessions',
    [
      'dimensions' => 'ga:date'
    ]
  );

  $data = $qry->getRows();
  if ($data && count($data) > 0) {
    return array_reduce($data, function ($carry, $item) {
      return $carry + $item[1];
    }, 0);
  }

  return 0;
}

function getDays($analytics, $min) {
  $qry = $analytics->data_ga->get(
    'ga:232325563',
    $min,
    'today',
    'ga:sessions',
    [
      'dimensions' => 'ga:date',
    ]
  );

  $data = $qry->getRows();

  return $data;
}

function getPages($analytics, $min) {
  $qry = $analytics->data_ga->get(
    'ga:232325563',
    $min,
    'today',
    'ga:sessions',
    [
      'dimensions' => 'ga:pageTitle',
      'sort' => '-ga:sessions'
    ]
  );

  $data = $qry->getRows();

  return $data;
}

function getPlans($analytics, $min) {
  $qry = $analytics->data_ga->get(
    'ga:232325563',
    $min,
    'today',
    'ga:sessions',
    [
      'dimensions' => 'ga:eventLabel',
      'sort' => '-ga:sessions'
    ]
  );

  $data = $qry->getRows();

  return $data;
}

class Analytics extends ResourceController {

  public function index() {
    $analytics = initializeAnalytics();

    $data = [
      'byYear' => getLastYear($analytics),
      'byWeek' => getLastWeek($analytics)
    ];

    return $this->response->setJSON($data);
  }

  public function extra() {
    $analytics = initializeAnalytics();

    $mode = $this->request->getGet('mode');

    $time = '7daysAgo';

    if ($mode == 365) {
      $time = '356daysAgo';
    }

    $days = getDays($analytics, '7daysAgo');
    $pages = getPages($analytics, $time);
    $plans = getPlans($analytics, $time);

    return $this->response->setJSON([
      'days' => $days,
      'pages' => $pages,
      'plans' => $plans
    ]);
  }
}
