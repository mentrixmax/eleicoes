<?php


namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;


class Migration extends ResourceController {
	public function migrate() {
		$migrate = \Config\Services::migrations();
		try {
			$migrate->latest();
			return $this->respondCreated();
		} catch (\Throwable $e) {
			return $this->respond(400);
		}
	}
}
