<?php


namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;


class News extends ResourceController {

	public function __construct() {
		$this->model = model('App\Models\News');
	}

	public function index() {
		$registered = $this->model->orderBy('created_at','DESC')->findAll();
		return $this->respond($registered);
	}

	public function create() {
		$input = $this->request->getJSON();
		$registered = $this->model->insert($input);
		if (!$registered) {
			return $this->respond($this->model->errors(), 400);
		}
		return $this->respondCreated();
	}

	public function show($id = NULL){
		$item = $this->model->find($id);
		if (!$item) {
			return $this->respond($this->model->errors(), 400);
		}
		return $this->respond($item);
	}

	public function update($id = NULL) {
		$input = $this->request->getJSON();
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->update($id, $input);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondUpdated();
		}
	}

	public function delete($id = NULL) {
		$item = $this->model->find($id);
		if ($item) {
			$registered = $this->model->delete($id);
			if (!$registered) {
				return $this->respond($this->model->errors(), 400);
			}
			return $this->respondDeleted();
		} else {
			return $this->respond($this->model->errors(), 400);
		}
	}
}
