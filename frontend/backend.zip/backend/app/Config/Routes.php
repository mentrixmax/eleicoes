<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
	require SYSTEMPATH . 'Config/Routes.php';
}

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('/paginas/(:any)', 'Home::index');

// --------- DB
$routes->get('/db/migrate', 'Migration::migrate');

// --------- USER 
$routes->post('auth', 'User::auth');

$routes->post('api/users', 'User::create');
$routes->get('api/users/(:num)', 'User::show/$1', ['filter' => 'auth']);
$routes->put('api/users/(:num)', 'User::update/$1', ['filter' => 'auth']);

$routes->post('api/contact', 'Contact::send');

// --------- ANALYTCS
$routes->get('api/analytics', 'Analytics::index', ['filter' => 'auth']);
$routes->get('api/analytics/extra', 'Analytics::extra', ['filter' => 'auth']);

// --------- NEWS
$routes->get('api/news', 'News::index');
$routes->get('api/news/(:num)', 'News::show/$1');
$routes->post('api/news', 'News::create', ['filter' => 'auth']);
$routes->put('api/news/(:num)', 'News::update/$1', ['filter' => 'auth']);
$routes->delete('api/news/(:num)', 'News::delete/$1', ['filter' => 'auth']);

// --------- PAGE
$routes->get('api/pages', 'Page::index');
$routes->get('api/pages/images', 'Page::images', ['filter' => 'auth']);
$routes->post('api/pages/images/upload', 'Page::images_upload', ['filter' => 'auth']);
$routes->get('api/pages/(:num)', 'Page::show/$1');
$routes->get('api/pages/name/(:alpha)', 'Page::getByName/$1');
$routes->post('api/pages', 'Page::create', ['filter' => 'auth']);
$routes->put('api/pages/(:num)', 'Page::update/$1', ['filter' => 'auth']);
$routes->delete('api/pages/(:num)', 'Page::delete/$1', ['filter' => 'auth']);

// --------- PLAN
$routes->get('api/plans', 'Plan::index');
$routes->get('api/plans/(:num)', 'Plan::show/$1');
$routes->post('api/plans', 'Plan::create', ['filter' => 'auth']);
$routes->put('api/plans/(:num)', 'Plan::update/$1', ['filter' => 'auth']);
$routes->delete('api/plans/(:num)', 'Plan::delete/$1', ['filter' => 'auth']);

// --------- SECTION
$routes->get('api/section', 'Section::index');
$routes->post('api/section', 'Section::create', ['filter' => 'auth']);
$routes->put('api/section/(:num)', 'Section::update/$1', ['filter' => 'auth']);
$routes->delete('api/section/(:num)', 'Section::delete/$1', ['filter' => 'auth']);

$routes->options('(:any)', 'User::options/$1');

/**
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
	require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
