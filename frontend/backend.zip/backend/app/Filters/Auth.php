<?php

namespace App\Filters;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;
use Exception;
use Firebase\JWT\JWT;

class Auth implements FilterInterface {

  use ResponseTrait;

  public function before(RequestInterface $req, $args = null) {
    try {
      $key        = Services::getSecret();
      $headers    = getallheaders();
      $authHeader = isset($headers["Authorization"])? $headers["Authorization"] : $headers["authorization"];
      $arr        = explode(" ",$authHeader);
      $token      = $arr[1];
      JWT::decode($token, $key, ['HS256']);
    } catch (\Exception $e) {
      return Services::response()
      ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED)
      ->setHeader('Access-Control-Allow-Origin', '*') //for allow any domain, insecure
      ->setHeader('Access-Control-Allow-Headers', '*') //for allow any headers, insecure
      ->setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    }
  }

  public function after(RequestInterface $req, ResponseInterface $res, $args = null) {
  }
}
