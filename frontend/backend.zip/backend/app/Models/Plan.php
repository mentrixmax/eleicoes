<?php

namespace App\Database\Models;

use CodeIgniter\Model;

class Plan extends Model {
  protected $table      = 'plans';
  protected $primaryKey = 'id';

  protected $returnType     = 'object';
  protected $useSoftDeletes = true;

  protected $allowedFields = ['title', 'description','img_url','color'];

  protected $useTimestamps = true;
  protected $createdField  = 'created_at';
  protected $updatedField  = 'updated_at';
  protected $deletedField  = 'deleted_at';

  protected $validationRules    = [
    'title'       => 'required',
    'color'       => 'required',
    'description' => 'required'
  ];

  protected $validationMessages = [];

  protected $skipValidation = false;
}
