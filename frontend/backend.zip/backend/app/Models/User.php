<?php

namespace App\Database\Models;

use CodeIgniter\Config\Services;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Model;

class User extends Model {
  protected $table      = 'users';
  protected $primaryKey = 'id';

  protected $returnType     = 'object';
  protected $useSoftDeletes = true;

  protected $allowedFields = ['name', 'email', 'password'];

  protected $useTimestamps = true;
  protected $createdField  = 'created_at';
  protected $updatedField  = 'updated_at';
  protected $deletedField  = 'deleted_at';

  protected $validationRules    = [
      'name'      => 'required|max_length[64]',
      'email'     => 'required|valid_email|max_length[84]|is_unique[users.email]',
      'password'  => 'required|min_length[8]|max_length[32]'
  ];

  protected $validationMessages = [
      'email' => [
          'is_unique' => 'O email informado já está em uso!',
          'required'  => 'O email é obrigatório!'
      ],
      'name' => [
        'required'  => 'O nome é obrigatório!'
      ],
      'password' => [
        'required'  => 'A senha é obrigatória!'
      ]
  ];
  protected $skipValidation     = false;

  protected $beforeInsert = ['hashPassword'];
  protected $beforeUpdate = ['hashPassword'];

  protected function hashPassword(array $data){
    
    if (!isset($data['data']['password'])) return $data;

    $data['data']['password_hash'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
    
    unset($data['data']['password']);

    return $data;
  }

  public function checkLogin(string $email){
    $user = $this->where('email',$email)->first();
    if(!$user){
      Services::response()->setStatusCode(ResponseInterface::HTTP_FORBIDDEN);
    }
    return $user;
  }
}
