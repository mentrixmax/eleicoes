<?php

namespace App\Database\Models;

use CodeIgniter\Model;

class Section extends Model {
  protected $table      = 'sections';
  protected $primaryKey = 'id';

  protected $returnType     = 'object';
  protected $useSoftDeletes = true;

  protected $allowedFields = ['label', 'content', 'plan_id'];

  protected $useTimestamps = true;
  protected $createdField  = 'created_at';
  protected $updatedField  = 'updated_at';
  protected $deletedField  = 'deleted_at';

  protected $validationRules    = [
    'label'   => 'required',
    'content' => 'required',
    'plan_id' => 'required|is_not_unique[plans.id]'
  ];

  protected $validationMessages = [];

  protected $skipValidation = false;
}
