<?php

namespace App\Database\Models;

use CodeIgniter\Model;

class News extends Model {
  protected $table      = 'news';
  protected $primaryKey = 'id';

  protected $returnType     = 'object';
  protected $useSoftDeletes = true;

  protected $allowedFields = ['title', 'link', 'img_url', 'is_video'];

  protected $useTimestamps = true;
  protected $createdField  = 'created_at';
  protected $updatedField  = 'updated_at';
  protected $deletedField  = 'deleted_at';

  protected $validationRules    = [
    'title'      => 'required',
    'img_url'  => 'required',
    'is_video'  => 'required',
  ];

  protected $validationMessages = [];

  protected $skipValidation = false;
}
